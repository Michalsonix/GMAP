#!/bin/bash

# ================== ŚCIEŻKI ==================
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WYNIKI_DIR="$SCRIPT_DIR/wyniki"
mkdir -p "$WYNIKI_DIR"

INTERFACE=""

# ================== UI ==================
banner() {
clear
cat << "EOF"
 ________   _____ ______   ________  ________
|\   ___  \|\   _ \  _   \|\   __  \|\   __  \
\ \  \\ \  \ \  \\\__\ \  \ \  \|\  \ \  \|\  \
 \ \  \\ \  \ \  \\|__| \  \ \   __  \ \   ____\
  \ \  \\ \  \ \  \    \ \  \ \  \ \  \ \  \___|
   \ \__\\ \__\ \__\    \ \__\ \__\ \__\ \__\
    \|__| \|__|\|__|     \|__|\|__|\|__|\|__|

              GMAPER – NMAP WRAPPER
EOF
}

pause() {
read -rp "ENTER aby kontynuować..."
}

# ================== INTERFEJS ==================
choose_interface() {
banner
echo "[+] Wybierz interfejs:"
mapfile -t IFACES < <(ip -o link show | awk -F': ' '{print $2}')
select iface in "${IFACES[@]}"; do
    [[ -n "$iface" ]] && INTERFACE="$iface" && break
done
}

# ================== SKAN SIECI ==================
scan_network() {
banner
read -rp "Podaj zakres sieci (np. 192.168.1.0/24): " NET

RESULT=$(sudo nmap -sn -e "$INTERFACE" "$NET")

echo
echo "1) Zapisz pełny wynik"
echo "2) Zapisz tylko IP (jedno IP = jedna linia)"
echo "3) Pokaż bez zapisu"
read -rp "Wybór: " CH

TS=$(date +"%Y%m%d_%H%M%S")

case $CH in
1)
    echo "$RESULT" > "$WYNIKI_DIR/siec_$TS.txt"
    echo "[+] Zapisano: wyniki/siec_$TS.txt"
;;
2)
    echo "$RESULT" | grep -oE "([0-9]{1,3}\.){3}[0-9]{1,3}" \
    > "$WYNIKI_DIR/onlyip_$TS.txt"
    echo "[+] Zapisano: wyniki/onlyip_$TS.txt"
;;
3)
    echo "$RESULT"
;;
esac
pause
}

# ================== SKAN PORTÓW ==================
scan_ports() {
banner
echo "1) Podaj IP"
echo "2) Z pliku (onlyip)"
read -rp "Wybór: " SRC

USE_FILE=0

if [[ $SRC == 1 ]]; then
    read -rp "Podaj IP: " TARGET
else
    mapfile -t FILES < <(ls "$WYNIKI_DIR"/onlyip_*.txt 2>/dev/null)
    [[ ${#FILES[@]} -eq 0 ]] && echo "Brak plików onlyip!" && pause && return

    echo "[+] Wybierz plik:"
    select f in "${FILES[@]}"; do
        TARGET="$f"
        USE_FILE=1
        break
    done
fi

echo
echo "1) Podstawowe"
echo "2) Dokładne"
echo "3) Agresywne (-A)"
read -rp "Typ skanowania: " TYPE

case $TYPE in
1) SCAN="-sS -T4" ;;
2) SCAN="-sS -sV -T4" ;;
3) SCAN="-A" ;;
esac

echo
echo "1) Zapisz do pliku"
echo "2) Pokaż bez zapisu"
read -rp "Wybór: " OUT

TS=$(date +"%Y%m%d_%H%M%S")
OUTFILE="$WYNIKI_DIR/porty_$TS.txt"

if [[ $OUT == 1 ]]; then
    if [[ $USE_FILE == 1 ]]; then
        sudo nmap $SCAN -e "$INTERFACE" -iL "$TARGET" | tee "$OUTFILE"
    else
        sudo nmap $SCAN -e "$INTERFACE" "$TARGET" | tee "$OUTFILE"
    fi
else
    if [[ $USE_FILE == 1 ]]; then
        sudo nmap $SCAN -e "$INTERFACE" -iL "$TARGET"
    else
        sudo nmap $SCAN -e "$INTERFACE" "$TARGET"
    fi
fi

pause
}

# ================== MENU ==================
main_menu() {
while true; do
banner
echo "[INTERFEJS]: $INTERFACE"
echo
echo "1) Skanowanie sieci"
echo "2) Skanowanie portów"
echo "3) Zmień interfejs"
echo "4) Wyjście"
read -rp "Wybór: " OPT

case $OPT in
1) scan_network ;;
2) scan_ports ;;
3) choose_interface ;;
4) exit 0 ;;
esac
done
}

# ================== START ==================
choose_interface
main_menu
